/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FormularioPropiedad extends JFrame {

    private JTextField nroCasaField, valorAdministracionField, saldoActualField, metrosCuadradosField;
    private static final String CSV_FILE = "listaPropiedades.csv"; 

    public FormularioPropiedad() {
        setTitle("Registro de Propiedad");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel nroCasaLabel = new JLabel("N° Casa:");
        nroCasaField = new JTextField(15);
        JLabel valorAdministracionLabel = new JLabel("Valor Administración:");
        valorAdministracionField = new JTextField(15);
        JLabel saldoActualLabel = new JLabel("Saldo Actual:");
        saldoActualField = new JTextField(15);
        JLabel metrosCuadradosLabel = new JLabel("Metros Cuadrados:");
        metrosCuadradosField = new JTextField(15);

        JButton registrarButton = new JButton("Registrar");
        registrarButton.addActionListener(e -> registrarPropiedad());

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(nroCasaLabel, gbc);
        gbc.gridx = 1;
        add(nroCasaField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(valorAdministracionLabel, gbc);
        gbc.gridx = 1;
        add(valorAdministracionField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(saldoActualLabel, gbc);
        gbc.gridx = 1;
        add(saldoActualField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(metrosCuadradosLabel, gbc);
        gbc.gridx = 1;
        add(metrosCuadradosField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(registrarButton, gbc);

        setLocationRelativeTo(null); 
    }

    private void registrarPropiedad() {
        String nroCasa = nroCasaField.getText();
        String valorAdministracion = valorAdministracionField.getText();
        String saldoActual = saldoActualField.getText();
        String metrosCuadrados = metrosCuadradosField.getText();

        if (nroCasa.isEmpty() || valorAdministracion.isEmpty() || saldoActual.isEmpty() || metrosCuadrados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
            if (!Files.exists(Paths.get(CSV_FILE))) {
                writer.write("N° Casa,Valor Administración,Saldo Actual,Metros Cuadrados\n"); 
            }
            writer.write(nroCasa + "," + "$"+ valorAdministracion + "," + "$"+saldoActual + "," + metrosCuadrados + "\n");
            JOptionPane.showMessageDialog(this, "Propiedad registrada exitosamente.");
            limpiarCampos();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al registrar la propiedad: " + ex.getMessage());
        }
    }

    private void limpiarCampos() {
        nroCasaField.setText("");
        valorAdministracionField.setText("");
        saldoActualField.setText("");
        metrosCuadradosField.setText("");
    }
}
