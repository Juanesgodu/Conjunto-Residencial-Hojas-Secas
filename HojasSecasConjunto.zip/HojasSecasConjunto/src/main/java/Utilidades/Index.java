/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import javax.swing.*;
import java.awt.*;

public class Index extends JFrame {
    public Index() {
        setTitle("Bienvenido a Hojas Secas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        Fondo backgroundPanel = new Fondo(backgroundImage);
        setContentPane(backgroundPanel);

        JLabel bienvenidaLabel = new JLabel("BIENVENIDO A HOJAS SECAS");
        bienvenidaLabel.setFont(new Font("Arial", Font.BOLD, 24)); 
        bienvenidaLabel.setForeground(Color.WHITE); 
        bienvenidaLabel.setHorizontalAlignment(SwingConstants.CENTER); 

        JButton registrarButton = new JButton("Registrarse");
        registrarButton.setPreferredSize(new Dimension(120, 30));
        registrarButton.addActionListener(e -> registrarUsuario());

        JButton iniciarSesionButton = new JButton("Iniciar Sesión");
        iniciarSesionButton.setPreferredSize(new Dimension(120, 30));
        iniciarSesionButton.addActionListener(e -> iniciarSesion());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20)); 
        buttonPanel.setOpaque(false); 

        buttonPanel.add(registrarButton);
        buttonPanel.add(iniciarSesionButton);

        backgroundPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.gridx = 0; 
        gbc.gridy = 0; 
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.anchor = GridBagConstraints.CENTER; 

        backgroundPanel.add(bienvenidaLabel, gbc);
        
        gbc.gridy = 1; 
        backgroundPanel.add(buttonPanel, gbc);

        setLocationRelativeTo(null); 
    }

    private void registrarUsuario() {
        Registro registro = new Registro();
        registro.setVisible(true);
        this.dispose(); 
    }

    private void iniciarSesion() {
        LogIn logIn = new LogIn();
        logIn.setVisible(true);
        this.dispose(); 
    }

}
