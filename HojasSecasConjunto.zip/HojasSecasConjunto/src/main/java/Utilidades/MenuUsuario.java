/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import javax.swing.*;
import java.awt.*;

public class MenuUsuario extends JFrame {
    public MenuUsuario() {
        setTitle("Menú de Usuario");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        Fondo backgroundPanel = new Fondo(backgroundImage);
        setContentPane(backgroundPanel);

        JLabel tituloLabel = new JLabel("Menú de Usuario");
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 20)); 
        tituloLabel.setForeground(Color.WHITE); 
        tituloLabel.setHorizontalAlignment(SwingConstants.CENTER); 

        backgroundPanel.setLayout(new BorderLayout()); 

        backgroundPanel.add(tituloLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20)); 
        buttonPanel.setOpaque(false); 

        JButton verFacturaButton = new JButton("Ver Factura");
        verFacturaButton.setPreferredSize(new Dimension(150, 30));
        verFacturaButton.addActionListener(e -> verFactura()); // Agregar lógica para ver factura

        JButton verSaldoButton = new JButton("Ver Saldo");
        verSaldoButton.setPreferredSize(new Dimension(150, 30));
        verSaldoButton.addActionListener(e -> verSaldo()); // Agregar lógica para ver saldo

        JButton verMultasButton = new JButton("Ver Multas");
        verMultasButton.setPreferredSize(new Dimension(150, 30));
        verMultasButton.addActionListener(e -> verMultas()); // Agregar lógica para ver multas

        buttonPanel.add(verFacturaButton);
        buttonPanel.add(verSaldoButton);
        buttonPanel.add(verMultasButton);

        backgroundPanel.add(buttonPanel, BorderLayout.CENTER);

        setLocationRelativeTo(null); 
    }

    private void verFactura() {
        // Lógica para mostrar la factura
        JOptionPane.showMessageDialog(this, "Aquí se mostrarían las facturas.");
    }

    private void verSaldo() {
        // Lógica para mostrar el saldo
        JOptionPane.showMessageDialog(this, "Aquí se mostraría el saldo.");
    }

    private void verMultas() {
        // Lógica para mostrar las multas
        JOptionPane.showMessageDialog(this, "Aquí se mostrarían las multas.");
    }
}
