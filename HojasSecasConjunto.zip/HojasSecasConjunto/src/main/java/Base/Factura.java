/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Base;

import java.util.Date;

public class Factura {
    private Propiedad propiedad;
    private int numeroFactura;
    private Date fecha;
    private double valorTotal;
    private double valorMultas;
    private Date fechaLimitePago;
    private double valorPagado;
    private double saldo;

    public Factura(Propiedad propiedad, int numeroFactura, Date fecha, double valorTotal, double valorMultas, Date fechaLimitePago, double valorPagado, double saldo) {
        this.propiedad = propiedad;
        this.numeroFactura = numeroFactura;
        this.fecha = fecha;
        this.valorTotal = valorTotal;
        this.valorMultas = valorMultas;
        this.fechaLimitePago = fechaLimitePago;
        this.valorPagado = valorPagado;
        this.saldo = saldo;
    }

    // Getters y Setters
    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public double getValorMultas() {
        return valorMultas;
    }

    public void setValorMultas(double valorMultas) {
        this.valorMultas = valorMultas;
    }

    public Date getFechaLimitePago() {
        return fechaLimitePago;
    }

    public void setFechaLimitePago(Date fechaLimitePago) {
        this.fechaLimitePago = fechaLimitePago;
    }

    public double getValorPagado() {
        return valorPagado;
    }

    public void setValorPagado(double valorPagado) {
        this.valorPagado = valorPagado;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Factura{");
        sb.append("propiedad=").append(propiedad);
        sb.append(", numeroFactura=").append(numeroFactura);
        sb.append(", fecha=").append(fecha);
        sb.append(", valorTotal=").append(valorTotal);
        sb.append(", valorMultas=").append(valorMultas);
        sb.append(", fechaLimitePago=").append(fechaLimitePago);
        sb.append(", valorPagado=").append(valorPagado);
        sb.append(", saldo=").append(saldo);
        sb.append('}');
        return sb.toString();
    }
    
}
