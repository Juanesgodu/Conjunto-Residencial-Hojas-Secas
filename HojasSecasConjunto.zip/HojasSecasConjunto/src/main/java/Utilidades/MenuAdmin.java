/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import Base.Reportes;
import javax.swing.*;
import java.awt.*;

public class MenuAdmin extends JFrame {

    public MenuAdmin() {
        setTitle("Menú de Administrador");
        setSize(600, 200); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        Fondo backgroundPanel = new Fondo(backgroundImage);
        setContentPane(backgroundPanel); 

        backgroundPanel.setLayout(new GridBagLayout()); 

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 

        JLabel tituloLabel = new JLabel("Menú de Administrador");
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 16)); 
        tituloLabel.setForeground(Color.WHITE); 

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3; 
        gbc.anchor = GridBagConstraints.CENTER; 
        backgroundPanel.add(tituloLabel, gbc);

        JButton gestionarPropietariosButton = new JButton("Gestionar Propietarios");
        JButton gestionarPropiedadesButton = new JButton("Gestionar Propiedades");
        JButton verReportesButton = new JButton("Ver Reportes");

        gestionarPropietariosButton.setPreferredSize(new Dimension(150, 30));
        gestionarPropiedadesButton.setPreferredSize(new Dimension(150, 30));
        verReportesButton.setPreferredSize(new Dimension(150, 30));

        gestionarPropietariosButton.addActionListener(e -> {
            FormularioPropietario formularioPropietario = new FormularioPropietario();
            formularioPropietario.setVisible(true);
        });
        
        gestionarPropiedadesButton.addActionListener(e -> {
            FormularioPropiedad formulario = new FormularioPropiedad();
            formulario.setVisible(true);
        });
        
        verReportesButton.addActionListener(e -> {
            Reportes reportes = new Reportes();
            reportes.setVisible(true);
        });

        gbc.gridwidth = 1; 
        gbc.gridx = 0;
        gbc.gridy = 1;
        backgroundPanel.add(gestionarPropietariosButton, gbc);

        gbc.gridx = 1;
        backgroundPanel.add(gestionarPropiedadesButton, gbc);

        gbc.gridx = 2;
        backgroundPanel.add(verReportesButton, gbc);

        setLocationRelativeTo(null); 
    }
}
