/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Base;

/**
 *
 * @author L E N O V O
 */
public class Propietario extends Persona {
    private String direccion;
    private String correoElectronico;
    private String profesion;

    public Propietario(String nombre, String id, String telefono, int edad, String direccion, String correoElectronico, String profesion) {
        super(nombre, id, telefono, edad);
        this.direccion = direccion;
        this.correoElectronico = correoElectronico;
        this.profesion = profesion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Propietario{");
        sb.append("direccion=").append(direccion);
        sb.append(", correoElectronico=").append(correoElectronico);
        sb.append(", profesion=").append(profesion);
        sb.append('}');
        return sb.toString();
    }
    
}
