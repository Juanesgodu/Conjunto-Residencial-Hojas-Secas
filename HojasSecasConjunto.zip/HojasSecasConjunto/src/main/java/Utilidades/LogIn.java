/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LogIn extends JFrame {
    private JTextField usuarioField;
    private JPasswordField passwordField;
    private static final String CSV_FILE = "usuariosRegistrados.csv"; 

    public LogIn() {
        setTitle("Inicio de Sesión");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        Fondo backgroundPanel = new Fondo(backgroundImage);
        setContentPane(backgroundPanel);

        backgroundPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 

        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioField = new JTextField(10); 
        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordField = new JPasswordField(10); 

        JButton iniciarSesionButton = new JButton("Iniciar Sesión");
        iniciarSesionButton.addActionListener(e -> iniciarSesion());

        gbc.gridx = 0;
        gbc.gridy = 0;
        backgroundPanel.add(usuarioLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        backgroundPanel.add(usuarioField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        backgroundPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        backgroundPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; 
        gbc.anchor = GridBagConstraints.CENTER;
        backgroundPanel.add(iniciarSesionButton, gbc);

        setLocationRelativeTo(null); 
    }

    private void iniciarSesion() {
        String usuario = usuarioField.getText();
        String password = new String(passwordField.getPassword());

        if (usuario.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        if (!Files.exists(Paths.get(CSV_FILE))) {
            JOptionPane.showMessageDialog(this, "No hay usuarios registrados.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String linea;
            boolean encontrado = false;
            while ((linea = reader.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos[0].equals(usuario) && datos[1].equals(password)) {
                    encontrado = true;
                    if (usuario.equals("admin")) {
                        abrirMenuAdmin();
                    } else {
                        JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso.");
                        this.dispose(); 
                        new MenuUsuario().setVisible(true); 
                    }
                    break;
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al leer el archivo de usuarios: " + ex.getMessage());
        }
    }

    private void abrirMenuAdmin() {
        JOptionPane.showMessageDialog(this, "Inicio de sesión como admin.");
        MenuAdmin menuAdmin = new MenuAdmin();
        menuAdmin.setVisible(true);
        this.dispose(); 
    }
}
