/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Registro extends JFrame {
    private JTextField usuarioField;
    private JPasswordField passwordField;
    private static final String CSV_FILE = "usuariosRegistrados.csv"; 

    public Registro() {
        setTitle("Registro de Usuario");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        Fondo backgroundPanel = new Fondo(backgroundImage);
        setContentPane(backgroundPanel);

        backgroundPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        
        JLabel usuarioLabel = new JLabel("Usuario:");
        usuarioField = new JTextField(10); 
        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordField = new JPasswordField(10); 
        
        JButton registrarButton = new JButton("Registrar");
        registrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarUsuario();
            }
        });

        JButton iniciarSesionButton = new JButton("Ir a Iniciar Sesión");
        iniciarSesionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirLogin();
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        backgroundPanel.add(usuarioLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        backgroundPanel.add(usuarioField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        backgroundPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        backgroundPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; 
        gbc.anchor = GridBagConstraints.CENTER;
        backgroundPanel.add(registrarButton, gbc);

        gbc.gridy = 3;
        backgroundPanel.add(iniciarSesionButton, gbc);

        setLocationRelativeTo(null); 
    }

    private void registrarUsuario() {
        String usuario = usuarioField.getText();
        String password = new String(passwordField.getPassword());

        if (usuario.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        try {
            if (!Files.exists(Paths.get(CSV_FILE))) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE))) {
                    writer.write("Usuario,Contraseña\n"); // Cabecera
                }
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
                writer.write(usuario + "," + password + "\n");
                JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente.");
                usuarioField.setText("");
                passwordField.setText("");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al registrar el usuario: " + ex.getMessage());
        }
    }

    private void abrirLogin() {
        LogIn login = new LogIn();
        login.setVisible(true);
        this.dispose(); 
    }
}
