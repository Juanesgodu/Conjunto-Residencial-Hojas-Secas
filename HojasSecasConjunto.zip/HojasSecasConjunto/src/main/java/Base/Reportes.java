/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Base;

import Utilidades.Fondo;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Reportes extends JFrame {
    private static final String CSV_PROPietarios = "listaPropietarios.csv"; 
    private static final String CSV_PROPiedades = "listaPropiedades.csv"; 

    public Reportes() {
        setTitle("Reportes");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 

        Image backgroundImage = Toolkit.getDefaultToolkit().getImage("src/main/resources/background.jpg");
        Fondo backgroundPanel = new Fondo(backgroundImage);
        setContentPane(backgroundPanel);

        backgroundPanel.setLayout(new FlowLayout()); 

        JButton reportePropietariosButton = new JButton("Reporte Propietarios");
        reportePropietariosButton.setPreferredSize(new Dimension(150, 30));
        reportePropietariosButton.addActionListener(e -> mostrarReportePropietarios());

        JButton reportePropiedadesButton = new JButton("Reporte Propiedades");
        reportePropiedadesButton.setPreferredSize(new Dimension(150, 30));
        reportePropiedadesButton.addActionListener(e -> mostrarReportePropiedades());

        backgroundPanel.add(reportePropietariosButton);
        backgroundPanel.add(reportePropiedadesButton);

        setLocationRelativeTo(null); 
    }

    private void mostrarReportePropietarios() {
        StringBuilder reportContent = new StringBuilder("Lista de Propietarios:\n");
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_PROPietarios))) {
            String linea;
            String cabecera = reader.readLine(); 
            if (cabecera != null) {
                reportContent.append(cabecera).append("\n"); 
            }
            while ((linea = reader.readLine()) != null) {
                reportContent.append(linea).append("\n"); 
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al leer el archivo de propietarios: " + ex.getMessage());
            return;
        }

        JTextArea textArea = new JTextArea(reportContent.toString());
        textArea.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(textArea), "Reporte Propietarios", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarReportePropiedades() {
        StringBuilder reportContent = new StringBuilder("Lista de Propiedades:\n");
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_PROPiedades))) {
            String linea;
            String cabecera = reader.readLine(); 
            if (cabecera != null) {
                reportContent.append(cabecera).append("\n"); 
            }
            while ((linea = reader.readLine()) != null) {
                reportContent.append(linea).append("\n"); 
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al leer el archivo de propiedades: " + ex.getMessage());
            return;
        }

        JTextArea textArea = new JTextArea(reportContent.toString());
        textArea.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(textArea), "Reporte Propiedades", JOptionPane.INFORMATION_MESSAGE);
    }
}