/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Base;

public class Propiedad {
    private Propietario propietario;
    private int numeroCasa;
    private double valorAdministracion;
    private double saldoActual;
    private double metrosCuadrados;

    public Propiedad(Propietario propietario, int numeroCasa, double valorAdministracion, double saldoActual, double metrosCuadrados) {
        this.propietario = propietario;
        this.numeroCasa = numeroCasa;
        this.valorAdministracion = valorAdministracion;
        this.saldoActual = saldoActual;
        this.metrosCuadrados = metrosCuadrados;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
    }

    public int getNumeroCasa() {
        return numeroCasa;
    }

    public void setNumeroCasa(int numeroCasa) {
        this.numeroCasa = numeroCasa;
    }

    public double getValorAdministracion() {
        return valorAdministracion;
    }

    public void setValorAdministracion(double valorAdministracion) {
        this.valorAdministracion = valorAdministracion;
    }

    public double getSaldoActual() {
        return saldoActual;
    }

    public void setSaldoActual(double saldoActual) {
        this.saldoActual = saldoActual;
    }

    public double getMetrosCuadrados() {
        return metrosCuadrados;
    }

    public void setMetrosCuadrados(double metrosCuadrados) {
        this.metrosCuadrados = metrosCuadrados;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Propiedad{");
        sb.append("propietario=").append(propietario);
        sb.append(", numeroCasa=").append(numeroCasa);
        sb.append(", valorAdministracion=").append(valorAdministracion);
        sb.append(", saldoActual=").append(saldoActual);
        sb.append(", metrosCuadrados=").append(metrosCuadrados);
        sb.append('}');
        return sb.toString();
    }
    
}
