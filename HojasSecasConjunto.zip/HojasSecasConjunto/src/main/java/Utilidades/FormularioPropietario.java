/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FormularioPropietario extends JFrame {

    private JTextField nombreField, idField, telefonoField, edadField, direccionField, correoField, profesionField;
    private static final String CSV_FILE = "listaPropietarios.csv"; 

    public FormularioPropietario() {
        setTitle("Registro de Propietario");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel nombreLabel = new JLabel("Nombre:");
        nombreField = new JTextField(15);
        JLabel idLabel = new JLabel("ID:");
        idField = new JTextField(15);
        JLabel telefonoLabel = new JLabel("Teléfono:");
        telefonoField = new JTextField(15);
        JLabel edadLabel = new JLabel("Edad:");
        edadField = new JTextField(15);
        JLabel direccionLabel = new JLabel("Dirección:");
        direccionField = new JTextField(15);
        JLabel correoLabel = new JLabel("Correo:");
        correoField = new JTextField(15);
        JLabel profesionLabel = new JLabel("Profesión:");
        profesionField = new JTextField(15);

        JButton registrarButton = new JButton("Registrar");
        registrarButton.addActionListener(e -> registrarPropietario());

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(nombreLabel, gbc);
        gbc.gridx = 1;
        add(nombreField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(idLabel, gbc);
        gbc.gridx = 1;
        add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(telefonoLabel, gbc);
        gbc.gridx = 1;
        add(telefonoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        add(edadLabel, gbc);
        gbc.gridx = 1;
        add(edadField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        add(direccionLabel, gbc);
        gbc.gridx = 1;
        add(direccionField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        add(correoLabel, gbc);
        gbc.gridx = 1;
        add(correoField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        add(profesionLabel, gbc);
        gbc.gridx = 1;
        add(profesionField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(registrarButton, gbc);

        setLocationRelativeTo(null); 
    }

    private void registrarPropietario() {
        String nombre = nombreField.getText();
        String id = idField.getText();
        String telefono = telefonoField.getText();
        String edad = edadField.getText();
        String direccion = direccionField.getText();
        String correo = correoField.getText();
        String profesion = profesionField.getText();

        if (nombre.isEmpty() || id.isEmpty() || telefono.isEmpty() || edad.isEmpty() || direccion.isEmpty() || correo.isEmpty() || profesion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
            if (!Files.exists(Paths.get(CSV_FILE))) {
                writer.write("Nombre,ID,Teléfono,Edad,Dirección,Correo,Profesión\n"); 
            }
            writer.write(nombre + "," + id + "," + telefono + "," + edad + "," + direccion + "," + correo + "," + profesion + "\n");
            JOptionPane.showMessageDialog(this, "Propietario registrado exitosamente.");
            limpiarCampos();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al registrar el propietario: " + ex.getMessage());
        }
    }

    private void limpiarCampos() {
        nombreField.setText("");
        idField.setText("");
        telefonoField.setText("");
        edadField.setText("");
        direccionField.setText("");
        correoField.setText("");
        profesionField.setText("");
    }
}
