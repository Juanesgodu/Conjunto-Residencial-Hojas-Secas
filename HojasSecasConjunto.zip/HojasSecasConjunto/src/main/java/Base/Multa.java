/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Base;

import java.util.Date;

public class Multa {
    private Factura factura;
    private String idMulta;
    private Date fechaMulta;
    private String descripcionMulta;
    private double valorMulta;
    private Date fechaMaximaPago;

    public Multa(Factura factura, String idMulta, Date fechaMulta, String descripcionMulta, double valorMulta, Date fechaMaximaPago) {
        this.factura = factura;
        this.idMulta = idMulta;
        this.fechaMulta = fechaMulta;
        this.descripcionMulta = descripcionMulta;
        this.valorMulta = valorMulta;
        this.fechaMaximaPago = fechaMaximaPago;
    }

    // Getters y Setters
    public Factura getFactura() {
        return factura;
    }

    public void setFactura(Factura factura) {
        this.factura = factura;
    }

    public String getIdMulta() {
        return idMulta;
    }

    public void setIdMulta(String idMulta) {
        this.idMulta = idMulta;
    }

    public Date getFechaMulta() {
        return fechaMulta;
    }

    public void setFechaMulta(Date fechaMulta) {
        this.fechaMulta = fechaMulta;
    }

    public String getDescripcionMulta() {
        return descripcionMulta;
    }

    public void setDescripcionMulta(String descripcionMulta) {
        this.descripcionMulta = descripcionMulta;
    }

    public double getValorMulta() {
        return valorMulta;
    }

    public void setValorMulta(double valorMulta) {
        this.valorMulta = valorMulta;
    }

    public Date getFechaMaximaPago() {
        return fechaMaximaPago;
    }

    public void setFechaMaximaPago(Date fechaMaximaPago) {
        this.fechaMaximaPago = fechaMaximaPago;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Multa{");
        sb.append("factura=").append(factura);
        sb.append(", idMulta=").append(idMulta);
        sb.append(", fechaMulta=").append(fechaMulta);
        sb.append(", descripcionMulta=").append(descripcionMulta);
        sb.append(", valorMulta=").append(valorMulta);
        sb.append(", fechaMaximaPago=").append(fechaMaximaPago);
        sb.append('}');
        return sb.toString();
    }
    
}
